<?php

return [
    'Title'                => '任务标题',
    'Url'                  => '链接',
    'All'                  => '全部',
    'My'                   => '个人',
    'Please select a user' => '请选择管理员',
    'New Dialog'           => '弹窗',
    'New Addtabs'          => '新选项卡',
    'Add to event'         => '添加到备选事件',
    'Add to calendar'      => '添加到日历',
    'Exist event'          => '备选事件',
    'Add event'            => '添加事件',
    'Remove after drop'    => '添加后移除事件',
    'Title tips'           => '事件标题,不能为空',
    'Link tips'            => '链接地址,可以为空',
    'Drag here to delete'  => '挺拽到这里删除',
    'Begintime'            => '开始时间',
    'Endtime'              => '结束时间',
    'Status'               => '状态'
];
